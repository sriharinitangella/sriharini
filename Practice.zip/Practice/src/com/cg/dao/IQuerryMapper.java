package com.cg.dao;

public interface IQuerryMapper {
	public static final String CHECKTABLE="SELECT COUNT(tname) FROM TAB WHERE tname='food_order'";
	
	public static final String GENERTESEQUENCE = "SELECT seq_order_id.currval FROM DUAL";
	public static final String INSERTQUERY = "INSERT INTO food_order values(seq_order_id.NEXTVAL,?,?,?,?)";
	
	public static final String GETDETAILS = "select * from food_order where order_id=?";

}
