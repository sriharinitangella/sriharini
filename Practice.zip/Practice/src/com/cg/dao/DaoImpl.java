package com.cg.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;







import com.cg.dao.IQuerryMapper;
import com.cg.exception.SwiggyReqException;
import com.cg.util.DBConnection;
import com.cg.bean.SwiggyBean;

public class DaoImpl implements IDao{
	
		
	
	
	
	Logger logger=Logger.getRootLogger();
	public DaoImpl()
	{
	PropertyConfigurator.configure("resources//log4j.properties");

	}
	/*******************************************************************************************************
	 - Function Name	:    addOrderDetails(SwiggyBean bean)
	 - Input Parameters	:	CabRequest cabRequest
	 - Return Type		:	int
	 - Throws			:  
	 - Author			:	sriharini
	 - Creation Date	:	10/07/2018
	 - Description		:	add cab request details made by the customer
	 ********************************************************************************************************/
	
	@Override
	public int addOrderDetails(SwiggyBean bean) {

		int rs =0;
		
		   ResultSet resultSet = null;
				
				int reqId=0;
	try {
		
		Connection con=DBConnection.getConnection();
		PreparedStatement ps=con.prepareStatement(IQuerryMapper.INSERTQUERY );
		
		
		ps.setString(1, bean.getCustname());
		ps.setString(2, bean.getPhNo());
		ps.setString(3,bean.getAddress());
		ps.setString(4,bean.getPincode());
		
		ps.executeUpdate();
		ps = con.prepareStatement(IQuerryMapper.GENERTESEQUENCE);
		resultSet=ps.executeQuery();
		resultSet.next();
		reqId=resultSet.getInt(1);
		bean.setReqId(reqId);	
		if(rs>0){
			System.out.println("Values inserted successfully");
		}
		
	} catch (Exception e) {
		System.out.println("DBConnection Problem");
		e.printStackTrace();
	}
	

	return reqId;
		
	}

	@Override
	public SwiggyBean getRequestDetails(int requestId)
			throws SwiggyReqException {
		Connection conn = DBConnection.getConnection();
		SwiggyBean bean=new SwiggyBean();
		try {
			PreparedStatement ps=conn.prepareStatement(IQuerryMapper. GETDETAILS);
			ps.setInt(1, requestId);
			ResultSet rs=ps.executeQuery();
			rs.next();
			
			bean.setReqId(rs.getInt(1));
			bean.setCustname(rs.getString(2));
			bean.setPhNo(rs.getString(3));
			bean.setAddress(rs.getString(4));
			bean.setPincode(rs.getString(5));
					
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
		return bean;
	}
	
}
