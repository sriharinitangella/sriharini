package com.cg.dao;

import com.cg.bean.SwiggyBean;
import com.cg.exception.SwiggyReqException;

public interface IDao {
	SwiggyBean getRequestDetails(int requestId) throws SwiggyReqException;

	public int addOrderDetails(SwiggyBean bean);
}
