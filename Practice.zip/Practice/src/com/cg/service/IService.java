package com.cg.service;


import com.cg.bean.SwiggyBean;
import com.cg.exception.SwiggyReqException;

public interface IService {
    SwiggyBean getRequestDetails(int requestId) throws SwiggyReqException;
	int addOrderDetails(SwiggyBean bean);
	boolean isValidName(String custname);
	boolean isvalidNumber(String phNo);
	boolean isValidAddress(String address);
	boolean isValidPincode(String pincode);
    String getOrderTime(String item);
    
}
