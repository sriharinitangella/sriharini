package com.cg.service;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.cg.bean.SwiggyBean;
import com.cg.dao.DaoImpl;
import com.cg.dao.IDao;
import com.cg.exception.SwiggyReqException;

public class ServiceImpl implements IService{
	
	IDao dao=null;
	/*******************************************************************************************************
	 - Function Name	:	isValidName(String custName)
	 - Input Parameters	:	String custName
	 - Return Type		:	boolean
	 - Throws			:   
	 - Author			:	sriharini
	 - Creation Date	:	10/07/2018
	 - Description		:	validates customername
	 ********************************************************************************************************/

	@Override
	public boolean isValidName(String custname) {
		Pattern p=Pattern.compile("[A-Z][a-zA-Z]*{3}");
		Matcher m=p.matcher(custname);
		if(m.matches())
			return true;
		else
			System.out.println("invalid Name the first letter must be capital and name should atleast three letters");
	        return false;
	}
	/*******************************************************************************************************
	 - Function Name	:	isValidNumber(String phoneNo)
	 - Input Parameters	:	String phoneNo
	 - Return Type		:	boolean
	 - Throws			:   
	 - Author			:   sriharini
	 - Creation Date	:	10/07/2018
	 - Description		:	validates phonenumber
	 ********************************************************************************************************/
	@Override
	public boolean isvalidNumber(String phNo) {
	Pattern p=Pattern.compile("[6-9]{1}[0-9]{9}");
	Matcher m=p.matcher(phNo);
	if(m.matches())
		return true;
	else
		System.out.println("invalid phone number check once");
	return false;
	}
	/*******************************************************************************************************
	 - Function Name	:	isValidNumber(String address)
	 - Input Parameters	:	String phoneNo
	 - Return Type		:	boolean
	 - Throws			:   
	 - Author			:	sriharini
	 - Creation Date	:	10/07/2018
	 - Description		:	validates address
	 ********************************************************************************************************/
	@Override
	public boolean isValidAddress(String address) {
		Pattern p=Pattern.compile("[A-Z][a-zA-Z]*{5}");
		Matcher m=p.matcher(address);
		if(m.matches())
		return true;
		else
			System.out.println("invalid adress the first letter must be capital letters");
		return false;
			
	}
	/*******************************************************************************************************
	 - Function Name	:	isValidNumber(String pincode)
	 - Input Parameters	:	String pincode
	 - Return Type		:	boolean
	 - Throws			:   
	 - Author			:	sriharini
	 - Creation Date	:	10/07/2018
	 - Description		:	validates pincode
	 ********************************************************************************************************/

	@Override
	public boolean isValidPincode(String pincode) {
		Pattern p=Pattern.compile("[0-9]{6}");
		Matcher m=p.matcher(pincode);
		if(m.matches())
			return true;
		else
			System.out.println("invalid pincode it should be 6 numbers00000000");
		return false;
	}
	/*******************************************************************************************************
	 - Function Name	:   getOrderTime(String item)
	 - Input Parameters	:	String phoneNo
	 - Return Type		:	boolean
	 - Throws			:   
	 - Author			:   sriharini
	 - Creation Date	:	10/07/2018
	 - Description		:	validates item
	 ********************************************************************************************************/
	@Override
	public String getOrderTime(String item) {
		if(item.equals("1"))
			return "your order:chicken biryani \norder will be deliver within 15 min";
		if(item.equals("2"))
			return "your order:chicken 65 \norder will be deliver within 30 min";		
		if(item.equals("3"))
			return "your order:butternon \norder will be deliver within 50 min";	
		if(item.equals("4"))
			return "your order:mushroomfry \norder will be deliver within 45 min";
		if(item.equals("5"))
			return "your order:chicken fried rice \norder will be deliver within 25 min";
		else			
		return null;
	}
	/*******************************************************************************************************
	 - Function Name	:	addOrderDetails(SwiggyBean bean)
	 - Input Parameters	:	String phoneNo
	 - Return Type		:	boolean
	 - Throws			:   
	 - Author			:   sriharini
	 - Creation Date	:	10/07/2018
	 - Description		:	add details to database
	 ********************************************************************************************************/
	@Override
	public int addOrderDetails(SwiggyBean bean) {
	 dao=new DaoImpl();
		return dao.addOrderDetails(bean);
	}
	/*******************************************************************************************************
	 - Function Name	:	getRequestDetails(int requestId)
	 - Input Parameters	:	int requestId
	 - Return Type		:	boolean
	 - Throws			:   
	 - Author			:   sriharini
	 - Creation Date	:	10/07/2018
	 - Description		:	get details from database
	 ********************************************************************************************************/
	@Override
	public SwiggyBean getRequestDetails(int requestId)
			throws SwiggyReqException {
		 dao=new DaoImpl();
		return dao.getRequestDetails(requestId);
	}

}
