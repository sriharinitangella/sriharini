package com.cg.exception;

public class SwiggyReqException extends Exception{
	public SwiggyReqException()
	{
		
	}
	public SwiggyReqException(String msg)
	{
		super(msg);
	}
	}


