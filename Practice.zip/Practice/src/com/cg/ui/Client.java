package com.cg.ui;

import java.util.Scanner;





import com.cg.bean.SwiggyBean;
import com.cg.exception.SwiggyReqException;
import com.cg.service.IService;
import com.cg.service.ServiceImpl;

public class Client {
	 static IService serv=null;
	 static SwiggyBean bean=null;
	
	public static void main(String[] args){
		Scanner scan = new Scanner(System.in);	
		 String custName;
		 String phNo;
		 String address;
		 String pincode;
		 String item;
		  int reqId;
	serv = new ServiceImpl();
	while(true)
	{
	System.out.println("Select option from the given menu");
	System.out.println("1) place order\n2) View Status\n3) Exit");
	int choice=scan.nextInt();
	
	switch(choice)
	{
	case 1:
		serv=new ServiceImpl();
		bean=new SwiggyBean();
		do{
			System.out.print("Enter the name of the customer:");
			custName=scan.next();
		}while(!serv.isValidName(custName));
		bean.setCustname(custName);
		do{
			System.out.print("Enter the phone number:");
			phNo=scan.next();
		}while(!serv.isvalidNumber(phNo));
		bean.setPhNo(phNo);
		do{
			System.out.print("Enter the address:");
			address=scan.next();
		}while(!serv.isValidAddress(address));
		bean.setAddress(address);
		do{
			System.out.print("Enter the pincode:");
			pincode=scan.next();
		}while(!serv.isValidPincode(pincode));
		
	
		
		bean.setPincode(pincode);
		reqId=bean.getReqId();
	        System.out.println("order food from the given menu:");
			System.out.println("1.chicken biryani");
			System.out.println("2.chicken 65");
			System.out.println("3.butternon");
			System.out.println("4.mashroom fry");
			System.out.println("5.chicken friedrice");
			item=scan.next();
			String time=serv.getOrderTime(item);
			
			if(time==null)
				System.out.println("there is no such type of item in the menu\n you have to order from the given menu");
			else{
				System.out.println(time);
				
				}
			int rs;
			rs=serv.addOrderDetails(bean);
			System.out.println("customer Information saved successfully");
			System.out.println("your request id is "+rs);
			break;
	case 2:
		System.out.print("Enter the requestId:");
		reqId=scan.nextInt();
		serv=new ServiceImpl();
		bean=new SwiggyBean();
		try {
			bean=serv.getRequestDetails(reqId);
			System.out.println("Name : "+bean.getCustname());
			System.out.println("Address : "+bean.getAddress());
			System.out.println("PhNo : "+bean.getPhNo());
			System.out.println("pincode : "+bean.getPincode());
			
		} catch (SwiggyReqException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	break;
	
	case 3:
		System.out.println("exited");
		System.exit(0);
		
		break;
		}
}
}}