package com.cg.xyz.ui;

import java.util.Scanner;

import com.cg.exception.LoanException;
import com.cg.xyz.bean.CustomerBean;
import com.cg.xyz.bean.Loan;
import com.cg.xyz.service.ILoanService;
import com.cg.xyz.service.LoanServiceImpl;

public class Client {
	
		static ILoanService serv=null;
		 static CustomerBean bean=null;
		 static Loan loans=null;

		public static void main(String[] args) throws LoanException{
			Scanner scan = new Scanner(System.in);	
		String custName;
		String address;
		String email;
		String mobile;
		long custId;
		int loan;
		Long loanId;
	    double loanAmount;
	    int duration;
        Long emi;
        int accept;
		while(true)
		{
		System.out.println("XYZ Finance Company Welcomes you");
		System.out.println("1) Register customer\n2) Exit");
		int choice=scan.nextInt();
		
		switch(choice)
		{
		case 1:
			serv=new LoanServiceImpl();
			bean=new CustomerBean();
			System.out.println("Register Customer");
			do{
				System.out.print("Enter the name of the customer:");
				custName=scan.next();
			}while(!serv.isValidName(custName));
			bean.setCustName(custName);
			 do{
					System.out.print("Enter the phone number:");
					mobile=scan.next();
				   }while(!serv.isvalidNumber(mobile));
		           bean.setMobile(mobile);
				 
	      
				do{
				System.out.print("Enter the address:");
				address=scan.next();
			}while(!serv.isValidAddress(address));
			bean.setAddress(address);
			 do{
		    	   System.out.print("Enter emailId:");
				email=scan.next();
			    }while(!serv.isValidEmailId(email));
			  bean.setEmail(email);
			  int rs;
				rs=serv.insertCust(bean);
				System.out.println("Customer Information saved succesfully");
				System.out.println("your Customer Id is "+rs);
				
					
			break;
	   case 2:
			
			System.out.println("exited");
			System.exit(0);
			
			break;
			
		    }
		int result=serv.applyLoan(bean);
		System.out.println("Do u wish to apply for a loan");
		System.out.println("select 1 or 2\n 1.yes\n 2.no");
		loan=scan.nextInt();
		if(loan==1){
			System.out.println("Enter the loan amount");
		loanAmount=scan.nextLong();
	bean.setLoanAmount(loanAmount);
		System.out.println("Enter the loan duration in years");
		 duration=scan.nextInt();
		bean.setDuration(duration);
		 emi=(long) ((loanAmount*9.5*(1+9.5)*duration*12)/((duration*12*10.5)-1));
		  System.out.println("for LoanAmount of "+loanAmount+"   years of   "+duration+"   your EMI per Month will be "+emi);
		  System.out.println("do u want to apply for loan now");
		  System.out.println("select 1 or 2\n 1.yes\n 2.no");
		  accept=scan.nextInt();
		  if(accept==1){
			  System.out.println("your loan details are registered\n Thank you");
			 System.out.println("your loanId is"+result);
		  }
		  else
			  System.out.println("ok\n thank you");
		}
		else
			System.out.println("exited\n thank you");
		}}}

		
		
	