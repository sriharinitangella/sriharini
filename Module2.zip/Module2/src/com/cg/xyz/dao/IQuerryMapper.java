package com.cg.xyz.dao;

public interface IQuerryMapper {
	public static final String INSERTQUERY = "INSERT INTO Customers values(Cust_seq.NEXTVAL,?,?,?,?)";
	public static final String CREATESEQUENCE="Create sequence Cust_seq start with 10001;";
	public static final String GENERTESEQUENCE = "SELECT Cust_seq.currval FROM DUAL";
	public static final String CREATETABLEC ="Create table Customers(Cust_id number(6) Primary Key,Cust_name Varchar2(25)Not null,Address Varchar2(25) Not null,Email Varchar2(30),mobileNo varchar2(10));";
	
    public static final String CREATETABLE="Create table Loan(Loan_id number(5) Primary Key,Loan_amt Number(20) Not null,Cust_id Number(6) not null references Customers(cust_id),Duration Number(5) not null);";
    public static final String CREATESEQUENCEL="Create sequence Loan_seq start with 50001;";
    public static final String INSERTQUERYL= "INSERT INTO Loan values(Loan_seq.NEXTVAL,?,customers(cust_id),?);";
    public static final String GENERTESEQUENCEL = "SELECT Loan_seq.currval FROM DUAL";
}