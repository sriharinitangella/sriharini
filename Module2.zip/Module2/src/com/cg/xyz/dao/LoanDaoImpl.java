package com.cg.xyz.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;




import com.cg.exception.LoanException;
import com.cg.util.DBConnection;
import com.cg.xyz.bean.CustomerBean;
import com.cg.xyz.bean.Loan;


public class LoanDaoImpl implements ILaonDao{
	Logger logger=Logger.getRootLogger();
	public LoanDaoImpl()
	{
	PropertyConfigurator.configure("resources//log4j.properties");

	}
	/*******************************************************************************************************
	 - Function Name	:    insertCust(CustomerBean bean)
	 - Input Parameters	:	CustomerBean bean
	 - Return Type		:	int
	 - Throws			:  
	 - Author			:	sriharini
	 - Creation Date	:	10/07/2018
	 - Description		:	add customer details made by the customer
	 ********************************************************************************************************/

	@Override
	public int insertCust(CustomerBean bean)  throws LoanException{
		int rs =0;
		
		   ResultSet resultSet = null;
				
				int reqId=0;
				try {
					
					Connection con=DBConnection.getConnection();
					PreparedStatement ps=con.prepareStatement(IQuerryMapper.INSERTQUERY );
					ps.setString(1, bean.getCustName());
					ps.setString(2,bean.getAddress());
		            ps.setString(3, bean.getEmail());
		            ps.setString(4,bean.getMobile());
		            
		            ps.executeUpdate();
		    		ps = con.prepareStatement(IQuerryMapper.GENERTESEQUENCE);
		    		resultSet=ps.executeQuery();
		    		resultSet.next();
		    		reqId=resultSet.getInt(1);
		    		bean.setCustId(reqId);
		    		
		    		
				} catch (Exception e) {
					System.out.println("DBConnection Problem");
					e.printStackTrace();
				}
				

				return reqId;
	}
	/*******************************************************************************************************
	 - Function Name	:    applyLoan(Loan loan)
	 - Input Parameters	:    Loan loan
	 - Return Type		:	int
	 - Throws			:  
	 - Author			:	sriharini
	 - Creation Date	:	10/07/2018
	 - Description		:	add customer details made by the customer
	 ********************************************************************************************************/
	@Override
	public int applyLoan(CustomerBean bean) {
		int result =0;
		 ResultSet resultSet = null;
				int LoanId=0;
try {
					
					Connection con=DBConnection.getConnection();
					PreparedStatement ps=con.prepareStatement(IQuerryMapper.INSERTQUERYL );
					ps.setDouble(1, bean.getLoanAmount());
					ps.setInt(2, bean.getDuration());
					 ps.executeUpdate();
					 ps = con.prepareStatement(IQuerryMapper.GENERTESEQUENCEL);
					 resultSet=ps.executeQuery();
			    		resultSet.next();
			    		LoanId=resultSet.getInt(1);
			    		bean.setCustId(LoanId);
} catch (Exception e) {
	System.out.println("DBConnection Problem");
	e.printStackTrace();
	}return LoanId;
}}
		
		
	

	
