package com.cg.xyz.dao;

import com.cg.exception.LoanException;
import com.cg.xyz.bean.CustomerBean;
import com.cg.xyz.bean.Loan;

public interface ILaonDao {
	public int insertCust(CustomerBean bean) throws LoanException;

	public int applyLoan(CustomerBean bean) throws LoanException;
	
	

}
