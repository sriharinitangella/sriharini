package com.cg.xyz.service;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.cg.exception.LoanException;
import com.cg.xyz.bean.CustomerBean;
import com.cg.xyz.bean.Loan;
import com.cg.xyz.dao.ILaonDao;
import com.cg.xyz.dao.LoanDaoImpl;



public class LoanServiceImpl implements ILoanService{
	ILaonDao dao=null;
	/*******************************************************************************************************
	 - Function Name	:	isValidName(String custName)
	 - Input Parameters	:	String custName
	 - Return Type		:	boolean
	 - Throws			:   
	 - Author			:	sriharini
	 - Creation Date	:	10/07/2018
	 - Description		:	validates customername
	 ********************************************************************************************************/


	@Override
	public boolean isValidName(String custname) throws LoanException{
	
	
			Pattern p=Pattern.compile("[A-Z][a-zA-Z]*{3}");
			Matcher m=p.matcher(custname);
			if(m.matches())
				return true;
			else
				System.out.println("invalid Name the first letter must be capital and name should atleast three letters");
		        return false;
		
	
	}
	/*******************************************************************************************************
	 - Function Name	:	isValidNumber(String phoneNo)
	 - Input Parameters	:	String phoneNo
	 - Return Type		:	boolean
	 - Throws			:   
	 - Author			:   sriharini
	 - Creation Date	:	10/07/2018
	 - Description		:	validates phonenumber
	 ********************************************************************************************************/
	@Override
	public boolean isvalidNumber(String mobile) throws LoanException{
		
		
		Pattern p=Pattern.compile("[6-9]{1}[0-9]{9}");
		Matcher m=p.matcher(mobile);
		if(m.matches())
			return true;
		else
			System.out.println("invalid phone number check once");
		return false;
		}
		
/*******************************************************************************************************
- Function Name	:	isValidNumber(String address)
- Input Parameters	:	String phoneNo
- Return Type		:	boolean
- Throws			:   
- Author			:	sriharini
- Creation Date	:	10/07/2018
- Description		:	validates address
********************************************************************************************************/
	@Override
	public boolean isValidAddress(String address) throws LoanException {
		
		Pattern p=Pattern.compile("[A-Z][a-zA-Z]*{5}");
		Matcher m=p.matcher(address);
		if(m.matches())
		return true;
		else
			System.out.println("invalid adress the first letter must be capital letters");
		return false;
	
	}
@Override
public boolean isValidEmailId(String email) throws LoanException{
	Pattern p=Pattern.compile("[a-zA-Z]*{1}[@]*{1}");
	Matcher m=p.matcher(email);
	if(m.matches())
	return true;
	else
		System.out.println("invalid emailId it must requre @ symbol");
	return false;
}
@Override
public int insertCust(CustomerBean bean) throws LoanException{
	dao=new LoanDaoImpl();
	return dao.insertCust(bean);
}
@Override
public int applyLoan(CustomerBean bean) throws LoanException{
	dao=new LoanDaoImpl();
	return dao.applyLoan(bean);
	
}}
