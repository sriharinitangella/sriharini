package com.cg.xyz.service;

import com.cg.exception.LoanException;
import com.cg.xyz.bean.CustomerBean;
import com.cg.xyz.bean.Loan;

public interface ILoanService {
	public int applyLoan(CustomerBean bean) throws LoanException;
	public int insertCust(CustomerBean bean) throws LoanException;
	boolean isValidName(String custname) throws LoanException;
	boolean isvalidNumber(String mobile) throws LoanException;
	boolean isValidAddress(String address) throws LoanException;
	boolean isValidEmailId(String email) throws LoanException;

}
