package com.cg.exception;

public class LoanException extends Exception{
	public LoanException()
	{
		
	}
	public  LoanException(String msg){
	
		super(msg);
	}
	}


